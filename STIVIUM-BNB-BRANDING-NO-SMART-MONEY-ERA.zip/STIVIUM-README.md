# Stivium — BNB Chain AI Agent Marketplace

Prototype submission for **BNB Chain Hackathon: The ** (Build the Era track).

## The idea

Today, finding an AI agent on BNB Chain means trusting a name and a follower count. **Stivium** is a marketplace that ranks agents the way a smart-money marketplace ranks opportunities: by **scarcity (Rarity)** and by **momentum (Trending)** — both computed from on-chain-style performance data, not vibes.

- **Rarity** answers "how hard would this be to replace?" — it rewards agents with a long track record, few true peers in their category, and consistent performance, not just agents that happen to be new and shiny.
- **Trending** answers "is demand for this agent accelerating right now?" — a momentum read on 24h/7d hire growth, so users can catch agents on the way up instead of only seeing whoever has the most hires historically.

This directly targets the hackathon's three judging criteria. What each one maps to in `index.html`:

### Functionality
The full journey works with zero Agent Studio knowledge required:
1. **Land** — a 3-step onboarding strip explains the marketplace before anything else.
2. **Find by category** — sidebar filter, agent counts shown per category, sort by rarity / trending / TVL / success rate.
3. **Understand what it does** — clicking any agent opens a detail view with a plain-language description, not just numbers.
4. **Activate** — a real (mocked) session-key style flow: set a spend cap, tick an allowlist of actions specific to that agent's category, pick an expiry, confirm. The result is a visible "activated" state you can inspect or revoke — there's no dead end.
5. A glossary in the sidebar and an empty-state message (instead of a blank grid) mean a first-time user is never stuck wondering what a term means or why nothing loaded.

### Data quality
Every score is shown, not just asserted:
- Opening an agent shows a **breakdown bar chart** of exactly what fed its rarity tier (scarcity, track record, consistency, verified) and its trending badge (24h growth, 7d growth, acceleration).
- Each card carries a **7-day sparkline** of hire activity, not just a single trending arrow.
- Each agent has a **category-specific metric** beyond the generic four stats — rebalances/week, max drawdown, net APY, or minimum health factor maintained — so the numbers are actually decision-relevant, not vanity counts.
- A mock "synced Ns ago" timestamp on each detail view signals this is meant to run against live data, not a static snapshot.

### Agent diversity
- A **diversity strip** at the top of the page shows agent count and average success rate per category side by side, so it's visibly balanced rather than one category dominating.
- All four categories (Rebalancing, Grid Trading, Yield Optimisation, Health Factor Monitoring) have the same number of agents, the same stat fields, the same detail view, and the same activation flow — no category gets a shallower experience than the others.

## How the scoring works (prototype logic, see `index.html`)

### Rarity score
```
rarity = 0.35 * scarcity      // 1 / (# live agents in the same category)
       + 0.30 * trackRecord   // normalized uptime in days
       + 0.25 * consistency   // success rate, category-percentile
       + 0.10 * verified      // audited / verified flag, boolean
```
Agents are then bucketed into tiers by percentile **within the current filtered set**, so rarity is always relative to what's actually on the floor:

| Tier | Percentile | Visual |
|---|---|---|
| Legendary | top 5% | amber glow, diamond mark |
| Epic | next 10% | violet mark |
| Rare | next 25% | teal mark |
| Uncommon | next 30% | slate mark |
| Common | remainder | no mark |

### Trending score
```
trending = 0.5 * growth24h + 0.3 * growth7d + 0.2 * acceleration
```
where `acceleration` compares the 24h growth rate against the 7d average to catch agents whose momentum is *increasing*, not just agents that are already big.

Badges: 🔥 Hot (top 20% of the marketplace), ▲ Rising (next 30%), — Flat, ▼ Cooling (negative net growth).

## What's real vs. mocked in this prototype

- **Real**: the scoring math, the filtering/sorting UI, the four-category coverage, the tier-bucketing logic, the rarity/trending breakdown charts, the sparklines, the activation flow's state machine (overview → setup → active → revoke), the glossary, the empty state, fully responsive layout.
- **Mocked**: the underlying agent metrics (peer count, TVL, uptime, hire counts, category-specific stats) — seeded sample data standing in for what would come from BNB Agent Studio / on-chain reads in a full build. The "activate" action updates local state only; it does not sign a real transaction yet.

## Next steps to make this a real submission

1. Swap the mock dataset for live reads from BNB Agent Studio's agent registry (deployment count, uptime, hire events).
2. Pull TVL/performance from on-chain state per agent (BscScan / subgraph).
3. Wire the "Hire" action to an actual session-key flow (Altana track) so hiring is a real, scoped on-chain transaction.
4. Add the required Agent Advantage Report view for the TermiX challenge — a side-by-side of a task done with vs. without a hired agent (time, cost, quality).

## Files

- `index.html` — self-contained interactive prototype (no build step, no dependencies to install — open it directly in a browser).
- `README.md` — this file.

## Running it

Just open `index.html` in any browser, or serve the folder:

```bash
python3 -m http.server 8000
# then visit http://localhost:8000
```
